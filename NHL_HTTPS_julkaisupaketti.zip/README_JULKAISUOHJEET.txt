NHL-KAUDEN AVAJAISET 15V – HTTPS-JULKAISUOHJEET
================================================

Tässä paketissa:
  index.html     – valmis NHL-soitin (taustakuva ja kuusi kuvaa upotettu)
  .nojekyll      – GitHub Pages -julkaisun avustiedosto
  README_JULKAISUOHJEET.txt – nämä ohjeet

EI VAADI PYTHONIA TAI OHJELMIEN ASENTAMISTA TAPAHTUMAPAIKALLE.
Tarvitset GitHub-tunnuksen ja selaimen, jossa on internetyhteys.

1. Avaa https://github.com/new ja kirjaudu GitHubiin.
2. Anna Repository name: nhl-avajaiset-15v
3. Valitse Public (maksuttomalla GitHub-tilillä).
4. Paina Create repository.
5. Avaa luodun repositorion välilehti Code ja valitse Add file -> Upload files.
6. Pura tämä ZIP tietokoneelle ja lisää julkaisuun index.html ja .nojekyll.
   Voit lisätä myös README_JULKAISUOHJEET.txt:n, mutta se ei ole pakollinen.
7. Valitse Commit changes.
8. Avaa Settings -> Pages.
9. Valitse Build and deployment -> Source: Deploy from a branch.
10. Branch: main, Folder: /(root). Tallenna Save-painikkeella.
11. Odota julkaisun valmistumista ja avaa Pages-sivun Visit site.
    Osoite on yleensä https://KAYTTAJATUNNUS.github.io/nhl-avajaiset-15v/
12. Käynnistä tapahtumapaikalla Chrome, Edge tai Firefox ja avaa HTTPS-linkki.
    Paina tarvittaessa F11 koko näytön selaintilaan.

TÄRKEÄÄ: KAPPALEIDEN SIIRTÄMINEN
--------------------------------
Nykyinen soittolista ei automaattisesti siirry toiselle selaimelle eikä
file:// / localhost -versiosta HTTPS-versioon.

A. Avaa vanha toimiva soitin siinä selaimessa, jossa kappaleet näkyvät.
B. Paina soittimen alapalkista Tallenna. Saat JSON-tiedoston.
C. Avaa julkaistu HTTPS-soitin ja valitse Tuo lista.
D. Valitse juuri ladattu JSON-tiedosto ja hyväksy tuonti.
E. Kappaleet tallentuvat tapahtumapaikan selaimeen.

JOS HALUAT SAMAN SOITTOLISTAN MYÖS UUSILLE KÄYTTÄJILLE:
- Nimeä tallennettu JSON-tiedosto playlist.json ja lataa se GitHubin
  repositorion juureen index.html-tiedoston viereen.
- Sivusto lataa sen automaattisesti, jos selaimessa ei vielä ole kappaleita.
- Tämä julkaisee kappalelistasi, mukaan lukien siihen tallennetut kuvat,
  kaikkien sivustolla vierailevien saataville. Älä julkaise yksityisiä tietoja.
- Uusien kävijöiden lista päivittyy playlist.json:stä, mutta aiemmin
  selaimeen tallennettu lista säilyy paikallisena, kunnes se korvataan tuonnilla.

MUIDEN TOIMINTOJEN HUOMIOT
--------------------------
- YouTube-upotus käyttää virallista IFrame API:a ja vaatii internetyhteyden.
- Spotify-upotukset voivat vaatia sisäänkirjautumisen ja rajoittaa toistoa.
- Suora MP3/MP4-URL on oltava selaimella saatavissa; palveluntarjoaja voi
  estää ulkoisen käytön tai CORS-rajoitukset voivat vaikuttaa visualisaattoriin.
- Kaikki YouTube-videot eivät salli upotusta. YouTube-virhe 153 voi edelleen
  johtua selaimen Referer-estosta tai sen lisäosista, vaikka HTTPS auttaa.
- Sivusto on julkinen! Älä lataa arkaluonteisia tietoja tai luvatta jaettavaa mediaa.
- Testaa tapahtumapaikan internetyhteys, kirjautuminen ja äänen ulostulo etukäteen.
- Jos haluat päivittää ulkoasun myöhemmin, korvaa index.html GitHubissa.

Viralliset ohjeet:
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
https://developers.google.com/youtube/terms/required-minimum-functionality
